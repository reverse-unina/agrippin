package com.nofatclips.androidtesting.model;

public interface Plottable {

	// Tagging interface
	
}
