package com.nofatclips.androidtesting.model;

public interface Testable {

	// Tagging interface
	
}
