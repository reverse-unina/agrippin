/** Automatically generated file. DO NOT MODIFY */
package it.unina.androidripper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}