package it.unina.androidripper;

import it.unina.androidripper.automation.ExtractorUtilities;
import it.unina.androidripper.automation.Resources;
import it.unina.androidripper.automation.RobotUtilities;
import it.unina.androidripper.automation.ScreenshotFactory;
import it.unina.androidripper.model.*;
import it.unina.androidripper.planning.TraceDispatcher;
import it.unina.androidripper.storage.PersistenceFactory;
import it.unina.androidripper.storage.ResumingPersistence;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import org.w3c.dom.Element;

import com.nofatclips.androidtesting.model.*;
import com.nofatclips.androidtesting.xml.XmlGraph;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;
import static it.unina.androidripper.Resources.*;
import static it.unina.androidripper.storage.Resources.*;

@SuppressWarnings("rawtypes")
public abstract class Engine extends ActivityInstrumentationTestCase2 implements SaveStateListener {
	
	@SuppressWarnings("unchecked")
	public Engine() {
		super(theClass);
		PersistenceFactory.registerForSavingState(this);
	}
	
	public abstract Session getNewSession();

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		if (getImageCaptor()!=null) {
			ScreenshotFactory.setImageCaptor(getImageCaptor());
		}
		getRobot().bind(this);
		getExtractor().extractState();
		Activity a = getExtractor().getActivity();
		getPersistence().setFileName(it.unina.androidripper.storage.Resources.FILE_NAME);
		getPersistence().setContext(a);
		ActivityDescription d = getExtractor().describeActivity();
		getAbstractor().setBaseActivity(d);
		Log.d("Carmine","Setup after resume or start");

		if (resume()) {
			Log.d("Carmine","Setup after resume");
			setupAfterResume();
		} else {
			Log.d("Carmine","Setup first start");
			setupFirstStart();
		}
	}
	
	protected void setUp2() throws Exception {
		super.setUp();
		if (getImageCaptor()!=null) {
			ScreenshotFactory.setImageCaptor(getImageCaptor());
		}
		getRobot().bind(this);
		getExtractor().extractState();
		Activity a = getExtractor().getActivity();
		getPersistence().setFileName(it.unina.androidripper.storage.Resources.FILE_NAME);
		getPersistence().setContext(a);
		ActivityDescription d = getExtractor().describeActivity();
		getAbstractor().setBaseActivity(d);
	}

	protected void setupFirstStart() {
		Log.i("androidripper", "Starting a new session");
		
		ResumingPersistence r = (ResumingPersistence)getPersistence();
		importActivitiyList(r);
		
		ActivityDescription d = getExtractor().describeActivity();
		//TODO ECCO QUI
		ActivityState baseActivity;
		Log.d("Carmine","Navigation value: "+navigation);
		if(!navigation){
			baseActivity = getAbstractor().createActivity(d);
		}
		else{
			baseActivity = getAbstractor().getBaseActivity(); 
		}
		
		getStrategy().addState(baseActivity);
		if (screenshotEnabled()) {
			takeScreenshot (baseActivity);
		}
		planFirstTests(baseActivity);
	}

	protected void setupAfterResume() {/* do nothing*/}
	
	public boolean testAndCrawl(Activity a) {
		/*for (Trace theTask: getScheduler()) {
			GregorianCalendar c=new GregorianCalendar();
			theTask.setDateTime(c.getTime().toString());
			getStrategy().setTask(theTask);
			process(theTask);*/
			ExtractorUtilities.setActivity(a);
			ActivityDescription d = getExtractor().describeActivity();
			ActivityState theActivity = getAbstractor().createActivity(d);
			//Log.d("Carmine","the current activity is "+theActivity.getName());
			boolean alreadyExplored = getStrategy().compareState(theActivity);
			
			if(!alreadyExplored)
				stop();

			return alreadyExplored;
			/*
			if (screenshotNeeded()) {
				takeScreenshot(theActivity);
			}
			getRobot().wait(Resources.SLEEP_AFTER_TASK);
			if (!getStrategy().checkForTransition()) continue;
			getAbstractor().setFinalActivity (theTassonk, theActivity);
			getPersistence().addTrace(theTask);
			if (canPlanTests(theActivity)) {
				planTests(theTask, theActivity);
			} else {
				doNotPlanTests();
			}
			if ( (getStrategy().checkForTermination()) || (getStrategy().checkForPause()) ) break;
			*/
		//}
	}
	
	
	public boolean testAndCrawl() {
		
		try {
			this.setUp2();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		Log.d("Carmine","Test and Crawl");
		boolean r = true;
		
		for (Trace theTask: getScheduler()) {
			GregorianCalendar c=new GregorianCalendar();
			theTask.setDateTime(c.getTime().toString());
			
			getStrategy().setTask(theTask);
			process(theTask);
			
			ActivityDescription d = getExtractor().describeActivity();
			ActivityState theActivity = getAbstractor().createActivity(d);
			
			Log.d("Carmine","Activity name: "+theActivity.getName()+ " ("
					+theActivity.getId()+")");
			
			r = getStrategy().compareState(theActivity);
			
			
			if (screenshotNeeded()) {
				takeScreenshot(theActivity);
			}
			getRobot().wait(Resources.SLEEP_AFTER_TASK);
			if (!getStrategy().checkForTransition()) continue;
			getAbstractor().setFinalActivity (theTask, theActivity);
			getPersistence().addTrace(theTask);
			if (canPlanTests(theActivity)) {
				planTests(theTask, theActivity);
			} else {
				doNotPlanTests();
			}
			
			RobotUtilities.wait(2000);			
			
			if ( (getStrategy().checkForTermination()) || (getStrategy().checkForPause()) ) break;
			
			
		}
		return r;
	}
	
	public void stop(){
		ContextWrapper w = new ContextWrapper(this.getActivity());
		FileOutputStream fOut;
		try {
			Log.d("Carmine","The end!!!");
			fOut = w.openFileOutput("stop.txt", ContextWrapper.MODE_PRIVATE);
			OutputStreamWriter osw = new OutputStreamWriter(fOut); 
			osw.write("the end");
			osw.flush();
			osw.close();
			fOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected void process(Trace theTask) {
		getRobot().process(theTask);
	}

	protected boolean canPlanTests (ActivityState theActivity){
		return (!(theActivity.isExit()) && getStrategy().checkForExploration());
	}
	
	@Override
	protected void tearDown() throws Exception {
		Log.d("Carmine","TearDown3");
		if ((getStrategy().getTask() != null) && (getStrategy().getTask().isFailed())) {
			getSession().addFailedTrace(getStrategy().getTask());
		}
		getPersistence().save();
		ok();
		getRobot().finalize();
		super.tearDown();
	}
	
	public void ok(){
		ContextWrapper w = new ContextWrapper(this.getActivity());
		FileOutputStream fOut;
		try {
			Log.d("Carmine","OK");
			fOut = w.openFileOutput("ok.txt", ContextWrapper.MODE_PRIVATE);
			OutputStreamWriter osw = new OutputStreamWriter(fOut); 
			osw.write("ok");
			osw.flush();
			osw.close();
			fOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public boolean resume() {
		boolean flag = ENABLE_RESUME;
		if (!flag) {
			Log.i("androidripper", "Resume not enabled.");
			return false;
		}
		if (!(getPersistence() instanceof ResumingPersistence)) {
			Log.w("androidripper", "The instance of Persistence does not implement Resuming.");
			return false;
		}
		
		ResumingPersistence r = (ResumingPersistence)getPersistence();
		if (!r.canHasResume()) return false;
		Log.i("androidripper", "Attempting to resume previous session");

		
		importTaskList(r);
		
		importActivitiyList(r);

		r.loadParameters();
		r.setNotFirst();
		r.saveStep();

		return true;
	}

	public void importActivitiyList(ResumingPersistence r) {
		if (getStrategy().getComparator() instanceof StatelessComparator) {
			Log.i("androidripper","Stateless comparator: the state file will not be loaded.");
			return;
		}
		List<String> entries;
		Session sandboxSession = getNewSession();
		Element e;
		entries = r.readStateFile();
		List<ActivityState> stateList = new ArrayList<ActivityState>();
		ActivityState s;
		for (String state: entries) {
			sandboxSession.parse(state);
			e = ((XmlGraph)sandboxSession).getDom().getDocumentElement();
			s = getAbstractor().importState (e);
			stateList.add(s);
			Log.d("androidripper", "Imported activity state " + s.getId() + " from disk");
		}
		
		for (ActivityState state: stateList) {
			getStrategy().addState(state);
		}
		
	}

	public void importTaskList(ResumingPersistence r) {
		boolean noLoadTasks = this instanceof MemorylessEngine;
		if (noLoadTasks) {
			Log.i("androidripper","Memoryless engine: the task file will not be loaded. Looking for crashed traces.");
		}
		List<String> entries;
		Session sandboxSession = getNewSession();
		Element e;
		entries = r.readTaskFile();
		List<Trace> taskList = new ArrayList<Trace>();
		Trace t;
		for (String trace: entries) {
			sandboxSession.parse(trace);
			e = ((XmlGraph)sandboxSession).getDom().getDocumentElement();
			t = getAbstractor().importTask (e);
			if (t.isFailed()) {
				//Log.d("androidripper", "Importing crashed trace #" + t.getId() + " from disk");
				//getSession().addCrashedTrace(t);
			} else if (noLoadTasks) {
				Log.v("androidripper", "Discarding trace #" + t.getId());
			} else {
				Log.d("androidripper", "Importing trace #" + t.getId() + " from disk");
				taskList.add(t);
			}
		}
		getScheduler().addTasks(taskList);
	}
	
	protected void planFirstTests (ActivityState theActivity) {
		Plan thePlan = getPlanner().getPlanForBaseActivity(theActivity);
		planTests (null, thePlan);
	}
	
	protected void planTests (Trace theTask, ActivityState theActivity) {
		Plan thePlan = getPlanner().getPlanForActivity(theActivity);
		planTests (theTask, thePlan);
	}
	
	protected void planTests (Trace baseTask, Plan thePlan) {
		List<Trace> tasks = new ArrayList<Trace>();
		for (Transition t: thePlan) {
			tasks.add(getNewTask(baseTask, t));
		}
		getScheduler().addPlannedTasks(tasks);
	}
	
	protected void doNotPlanTests() { 
		// do nothing 
	}
	
	protected Trace getNewTask (Trace theTask, Transition t) {
		Trace newTrace = getAbstractor().createTrace(theTask, t);
		newTrace.setId(nextId());
		return newTrace;
	}
	
	public SessionParams onSavingState () {
		return new SessionParams (PARAM_NAME, this.id);
	}
	
	public void onLoadingState(SessionParams sessionParams) {
		this.id = sessionParams.getInt(PARAM_NAME);
		Log.d("androidripper","Restored trace count to " + this.id);
	}
	
	public Robot getRobot() {
		return this.theRobot;
	}

	public void setRobot(Robot theRobot) {
		this.theRobot = theRobot;
	}

	public Extractor getExtractor() {
		return this.theExtractor;
	}

	public void setExtractor(Extractor theExtractor) {
		this.theExtractor = theExtractor;
	}
	
	public ImageCaptor getImageCaptor() {
		return this.theImageCaptor;
	}

	public void setImageCaptor(ImageCaptor theImageCaptor) {
		this.theImageCaptor = theImageCaptor;
	}

	public Abstractor getAbstractor() {
		return this.theAbstractor;
	}

	public void setAbstractor(Abstractor theAbstractor) {
		this.theAbstractor = theAbstractor;
	}

	public Planner getPlanner() {
		return this.thePlanner;
	}

	public void setPlanner(Planner thePlanner) {
		this.thePlanner = thePlanner;
	}
	
	public TraceDispatcher getScheduler () {
		return this.theScheduler;
	}
	
	public void setScheduler (TraceDispatcher theScheduler) {
		this.theScheduler = theScheduler;
	}

	public Strategy getStrategy() {
		return this.theStrategy;
	}

	public void setStrategy(Strategy theStrategy) {
		this.theStrategy = theStrategy;
	}
	
	public Persistence getPersistence() {
		return this.thePersistence;
	}

	public void setPersistence(Persistence thePersistence) {
		this.thePersistence = thePersistence;
	}
	
	public Session getSession() {
		return this.theSession;
	}

	public void setSession(Session theSession) {
		this.theSession = theSession;
	}
	
	public int getLastId() {
		return this.id;
	}
	
	protected String nextId () {
		int num = id;
		id++;
		return String.valueOf(num);
	}
	
	public String getListenerName () {
		return ACTOR_NAME;
	}
	
	public boolean screenshotEnabled() {
		return it.unina.androidripper.automation.Resources.SCREENSHOT_FOR_STATES;
	}
	
	public boolean screenshotEveryTrace() {
		return !it.unina.androidripper.automation.Resources.SCREENSHOT_ONLY_NEW_STATES;
	}
	
	public boolean screenshotNeeded() {
		if (!screenshotEnabled()) return false; // Function disable, always return false
		if (screenshotEveryTrace()) return true; // Function enable for all states, always return true
		return !(getStrategy().isLastComparationPositive()); // Function enabled for new states only: return true if comparation was false
	}
	
	public String screenshotName (String stateId) {
		return stateId + "." + ScreenshotFactory.getFileExtension();
	}
	
	private void takeScreenshot(ActivityState theActivity) {
		if (theActivity.isExit()) return;
		String fileName = screenshotName(theActivity.getUniqueId());
		if (ScreenshotFactory.saveScreenshot(fileName)) {
			theActivity.setScreenshot(fileName);
		}
	}

	public final static String ACTOR_NAME = "Engine";
	
	private Robot theRobot;
	private Extractor theExtractor;
	private Abstractor theAbstractor;
	private Planner thePlanner;
	private TraceDispatcher theScheduler;
	private Strategy theStrategy;
	private Persistence thePersistence;
	private Session theSession;
	private ImageCaptor theImageCaptor;
	
	private final static String PARAM_NAME = "taskId";
	private int id = 0;
	private boolean resumed = false;

}
