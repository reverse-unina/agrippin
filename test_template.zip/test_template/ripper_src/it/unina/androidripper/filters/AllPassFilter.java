package it.unina.androidripper.filters;

import android.view.View;

public class AllPassFilter extends ArrayListFilter {

	public boolean isValidItem(View v) {
		return true;
	}

}
