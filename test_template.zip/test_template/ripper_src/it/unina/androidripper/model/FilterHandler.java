package it.unina.androidripper.model;


public interface FilterHandler extends Iterable<Filter> {
	
	public void addFilter (Filter f);

}
