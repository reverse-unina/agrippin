package it.unina.androidripper.model;

import android.graphics.Bitmap;

public interface ImageCaptor {

	public Bitmap captureImage ();
	
}
