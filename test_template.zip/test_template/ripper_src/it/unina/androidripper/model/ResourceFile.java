package it.unina.androidripper.model;

public interface ResourceFile {
 
}
