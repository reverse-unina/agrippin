package it.unina.androidripper.model;

import android.app.Activity;

public interface Restarter {
	
	public void restart ();
	public void setRestartPoint (Activity a);

}
