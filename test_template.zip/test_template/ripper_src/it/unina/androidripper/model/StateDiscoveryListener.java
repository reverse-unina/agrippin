package it.unina.androidripper.model;

import com.nofatclips.androidtesting.model.ActivityState;

public interface StateDiscoveryListener {

	public void onNewState (ActivityState newState);
	
}
