package it.unina.androidripper.model;

public interface StrategyCriteria {
	
	public void setStrategy (Strategy theStrategy);

}
