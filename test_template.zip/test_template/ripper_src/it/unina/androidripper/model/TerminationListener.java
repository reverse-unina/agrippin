package it.unina.androidripper.model;

public interface TerminationListener {

	public void onTerminate();
	
}
