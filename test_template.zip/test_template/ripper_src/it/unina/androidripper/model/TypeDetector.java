package it.unina.androidripper.model;

import android.view.View;

public interface TypeDetector {
	
	public String getSimpleType (View v);

}
