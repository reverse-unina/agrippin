package it.unina.androidripper.planning.adapters;

import java.util.Random;

public interface RandomInteractor {
	
	public void setRandomGenerator (Random r);

}
