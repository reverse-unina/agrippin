package it.unina.androidripper.strategy.criteria;

import it.unina.androidripper.model.StrategyCriteria;

public interface PauseCriteria extends StrategyCriteria {
	
	public boolean pause ();

}
