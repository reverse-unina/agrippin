package it.unina.androidripper.strategy.criteria;

import it.unina.androidripper.model.StrategyCriteria;

public interface TerminationCriteria extends StrategyCriteria {
	
	public boolean termination ();

}
