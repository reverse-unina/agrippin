package it.unina.androidripper.strategy.criteria;

import it.unina.androidripper.model.StrategyCriteria;

public interface TransitionCriteria extends StrategyCriteria {
	
	public boolean transition ();

}
