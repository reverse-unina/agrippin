package it.unina.androidripper;


public class AndroidGuiTest extends AndroidGuiTestHelper {

	boolean found = false;

	public AndroidGuiTest(){
		super();
	}


	public void Crawl() {
		solo.sleep(4000);
		retrieveWidgets();
		this.crawler(this.getActivity(),"Crawler",0);
	}


	public static void preCrawl() {

	}

	public void testTrace00028(){
		boolean newState = false;
		String testname = "testTrace00028";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e28
			fireEvent (16908306, 9, "", "tabHost", "swapTab", "3");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00034(){
		boolean newState = false;
		String testname = "testTrace00034";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e34
			fireEvent (16908314, 21, "Cancel", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00048(){
		boolean newState = false;
		String testname = "testTrace00048";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i5
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e8
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "2");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00049(){
		boolean newState = false;
		String testname = "testTrace00049";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e33
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e29
			fireEvent (16908306, 9, "", "tabHost", "swapTab", "4");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00060(){
		boolean newState = false;
		String testname = "testTrace00060";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "nonsenseword");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00061(){
		boolean newState = false;
		String testname = "testTrace00061";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e36
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00062(){
		boolean newState = false;
		String testname = "testTrace00062";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e35
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00068(){
		boolean newState = false;
		String testname = "testTrace00068";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e27
			fireEvent (16908306, 9, "", "tabHost", "swapTab", "2");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00070(){
		boolean newState = false;
		String testname = "testTrace00070";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "0");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e27
			fireEvent (16908310, 4, "Zoom In", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00074(){
		boolean newState = false;
		String testname = "testTrace00074";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "R:/test");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00077(){
		boolean newState = false;
		String testname = "testTrace00077";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e34
			fireEvent (16908314, 21, "Cancel", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e35
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (16908315, 20, "Dismiss", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00079(){
		boolean newState = false;
		String testname = "testTrace00079";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00080(){
		boolean newState = false;
		String testname = "testTrace00080";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "40�50'00\"N 14�15'00\"E");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00084(){
		boolean newState = false;
		String testname = "testTrace00084";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "10");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e25
			fireEvent (16908310, 2, "New Lookup", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00085(){
		boolean newState = false;
		String testname = "testTrace00085";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "13:20");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00091(){
		boolean newState = false;
		String testname = "testTrace00091";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e2
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00097(){
		boolean newState = false;
		String testname = "testTrace00097";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i5
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e8
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "4");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00109(){
		boolean newState = false;
		String testname = "testTrace00109";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e20
			fireEvent (2131099650, 11, "", "webPage", "longClick");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00110(){
		boolean newState = false;
		String testname = "testTrace00110";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00113(){
		boolean newState = false;
		String testname = "testTrace00113";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (16908310, 1, "View Online", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00114(){
		boolean newState = false;
		String testname = "testTrace00114";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e25
			fireEvent (16908310, 2, "New Lookup", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00115(){
		boolean newState = false;
		String testname = "testTrace00115";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e26
			fireEvent (16908310, 3, "Zoom Out", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00116(){
		boolean newState = false;
		String testname = "testTrace00116";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e27
			fireEvent (16908310, 4, "Zoom In", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00117(){
		boolean newState = false;
		String testname = "testTrace00117";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e2
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e33
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e29
			fireEvent (16908306, 9, "", "tabHost", "swapTab", "4");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00118(){
		boolean newState = false;
		String testname = "testTrace00118";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00119(){
		boolean newState = false;
		String testname = "testTrace00119";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "nonsenseword");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "13:20");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00120(){
		boolean newState = false;
		String testname = "testTrace00120";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00121(){
		boolean newState = false;
		String testname = "testTrace00121";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e28
			fireEvent (16908306, 9, "", "tabHost", "swapTab", "3");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e27
			fireEvent (16908306, 9, "", "tabHost", "swapTab", "2");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00122(){
		boolean newState = false;
		String testname = "testTrace00122";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00123(){
		boolean newState = false;
		String testname = "testTrace00123";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e34
			fireEvent (16908314, 21, "Cancel", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e35
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (16908315, 20, "Dismiss", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "nonsenseword");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00124(){
		boolean newState = false;
		String testname = "testTrace00124";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00125(){
		boolean newState = false;
		String testname = "testTrace00125";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e25
			fireEvent (16908310, 2, "New Lookup", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00126(){
		boolean newState = false;
		String testname = "testTrace00126";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "10");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e27
			fireEvent (16908310, 4, "Zoom In", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00127(){
		boolean newState = false;
		String testname = "testTrace00127";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e34
			fireEvent (16908314, 21, "Cancel", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e35
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e36
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (2131099653, 10, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00128(){
		boolean newState = false;
		String testname = "testTrace00128";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (16908315, 20, "Dismiss", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00129(){
		boolean newState = false;
		String testname = "testTrace00129";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "nonsenseword");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00130(){
		boolean newState = false;
		String testname = "testTrace00130";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i5
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e8
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "4");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00131(){
		boolean newState = false;
		String testname = "testTrace00131";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e26
			fireEvent (16908310, 3, "Zoom Out", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00132(){
		boolean newState = false;
		String testname = "testTrace00132";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i5
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e8
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "2");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00133(){
		boolean newState = false;
		String testname = "testTrace00133";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e34
			fireEvent (16908314, 21, "Cancel", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e35
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (16908315, 20, "Dismiss", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00134(){
		boolean newState = false;
		String testname = "testTrace00134";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e35
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00135(){
		boolean newState = false;
		String testname = "testTrace00135";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e44
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e34
			fireEvent (16908314, 21, "Cancel", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e35
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e38
			fireEvent (16908310, 3, "Scan Device", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (16908315, 20, "Dismiss", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00136(){
		boolean newState = false;
		String testname = "testTrace00136";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e6
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e12
			fireEvent (16908310, 1, "Dictionaries", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (2131099653, 10, "", "listView", "longClickListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e34
			fireEvent (16908314, 21, "Cancel", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00137(){
		boolean newState = false;
		String testname = "testTrace00137";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "4");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e24
			fireEvent (16908310, 1, "View Online", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00138(){
		boolean newState = false;
		String testname = "testTrace00138";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i0
			setInput (2131099659, "writeText", "3");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e17
			fireEvent (2131099660, 12, "", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00139(){
		boolean newState = false;
		String testname = "testTrace00139";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "5");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e26
			fireEvent (16908310, 3, "Zoom Out", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00140(){
		boolean newState = false;
		String testname = "testTrace00140";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "work");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "10");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e22
			fireEvent (0, "", "null", "openMenu");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e25
			fireEvent (16908310, 2, "New Lookup", "menuItem", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00141(){
		boolean newState = false;
		String testname = "testTrace00141";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "2");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00142(){
		boolean newState = false;
		String testname = "testTrace00142";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i5
			setInput (2131099659, "writeText", "6502530000");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e8
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "2");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00143(){
		boolean newState = false;
		String testname = "testTrace00143";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "Rome");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "4");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e21
			fireEvent (0, "", "null", "back");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}

	public void testTrace00144(){
		boolean newState = false;
		String testname = "testTrace00144";
		int tr=-1;
		int in=0;

		if(!found){
			//Testing base activity

			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e1
			fireEvent (2131099656, 13, "Scan Device", "button", "click");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e7
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e3
			fireEvent (0, "", "null", "changeOrientation");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			solo.sleep(5000);

			//Testing transition
			//Setting input: i2
			setInput (2131099659, "writeText", "�$?.,���<>�\\/|***stringa***");
			solo.sleep(5000);

			retrieveWidgets();
			in++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			//Firing event: e5
			fireEvent (2131099663, 14, "", "listView", "selectListItem", "1");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			in=0;
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}
			//Firing event: e20
			fireEvent (2131099650, 11, "", "webPage", "longClick");

			in = 0;
			solo.sleep(5000);

			retrieveWidgets();
			tr++;
			newState = isAlreadyExploredState(this.getActivity(),testname,tr,in);
			if(newState){
				found=true;
				return;
			}

			solo.sleep (SLEEP_AFTER_TASK);
			}
		}
	}
