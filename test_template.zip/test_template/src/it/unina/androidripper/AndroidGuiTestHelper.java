package it.unina.androidripper;


import static android.content.Context.WINDOW_SERVICE;
import static android.view.Surface.ROTATION_0;
import static android.view.Surface.ROTATION_180;
import static com.nofatclips.androidtesting.model.InteractionType.AUTO_TEXT;
import static com.nofatclips.androidtesting.model.InteractionType.BACK;
import static com.nofatclips.androidtesting.model.InteractionType.CHANGE_ORIENTATION;
import static com.nofatclips.androidtesting.model.InteractionType.CLICK;
import static com.nofatclips.androidtesting.model.InteractionType.CLICK_ON_TEXT;
import static com.nofatclips.androidtesting.model.InteractionType.DRAG;
import static com.nofatclips.androidtesting.model.InteractionType.FOCUS;
import static com.nofatclips.androidtesting.model.InteractionType.HOME_ACTION;
import static com.nofatclips.androidtesting.model.InteractionType.LIST_LONG_SELECT;
import static com.nofatclips.androidtesting.model.InteractionType.LIST_SELECT;
import static com.nofatclips.androidtesting.model.InteractionType.LONG_CLICK;
import static com.nofatclips.androidtesting.model.InteractionType.OPEN_MENU;
import static com.nofatclips.androidtesting.model.InteractionType.PRESS_KEY;
import static com.nofatclips.androidtesting.model.InteractionType.RADIO_SELECT;
import static com.nofatclips.androidtesting.model.InteractionType.SCROLL_DOWN;
import static com.nofatclips.androidtesting.model.InteractionType.SEARCH_TEXT;
import static com.nofatclips.androidtesting.model.InteractionType.SET_BAR;
import static com.nofatclips.androidtesting.model.InteractionType.SPINNER_SELECT;
import static com.nofatclips.androidtesting.model.InteractionType.SWAP_TAB;
import static com.nofatclips.androidtesting.model.InteractionType.TYPE_TEXT;
import static com.nofatclips.androidtesting.model.InteractionType.WRITE_TEXT;
import it.unina.androidripper.automation.Automation;
import it.unina.androidripper.automation.BasicRestarter;
import it.unina.androidripper.automation.ExtractorUtilities;
import it.unina.androidripper.automation.RobotUtilities;
import it.unina.androidripper.automation.SimpleTypeDetector;
import it.unina.androidripper.filters.AllPassFilter;
import it.unina.androidripper.filters.FormFilter;
import it.unina.androidripper.guitree.GuiTreeAbstractor;
import it.unina.androidripper.guitree.GuiTreeEngine;
import it.unina.androidripper.model.ActivityDescription;
import it.unina.androidripper.model.Comparator;
import it.unina.androidripper.model.Extractor;
import it.unina.androidripper.model.Filter;
import it.unina.androidripper.model.Strategy;
import it.unina.androidripper.model.UserAdapter;
import it.unina.androidripper.strategy.comparator.CustomWidgetsIntensiveComparator;
import it.unina.androidripper.strategy.comparator.CustomWidgetsSimpleComparator;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;

import com.jayway.android.robotium.solo.Solo;
import com.nofatclips.androidtesting.guitree.GuiTree;
import com.nofatclips.androidtesting.model.ActivityState;
import com.nofatclips.androidtesting.xml.XmlGraph;

import it.unina.androidripper.Engine;
import it.unina.androidripper.automation.*;
import it.unina.androidripper.filters.*;
import it.unina.androidripper.model.*;
import it.unina.androidripper.planning.*;
import it.unina.androidripper.planning.interactors.values_cache.ValuesCache;
import it.unina.androidripper.storage.PersistenceFactory;
import it.unina.androidripper.strategy.*;
import it.unina.androidripper.strategy.comparator.Resources;

import java.util.GregorianCalendar;
import javax.xml.parsers.ParserConfigurationException;

import android.content.Context;
import android.util.Log;

import com.nofatclips.androidtesting.guitree.GuiTree;
import com.nofatclips.androidtesting.model.Session;

import static it.unina.androidripper.Resources.*;
import static it.unina.androidripper.automation.Resources.*;
import static it.unina.androidripper.automation.RobotUtilities.ActionBarHome;
import static it.unina.androidripper.automation.RobotUtilities.changeOrientation;
import static it.unina.androidripper.automation.RobotUtilities.click;
import static it.unina.androidripper.automation.RobotUtilities.clickOnText;
import static it.unina.androidripper.automation.RobotUtilities.drag;
import static it.unina.androidripper.automation.RobotUtilities.focus;
import static it.unina.androidripper.automation.RobotUtilities.goBack;
import static it.unina.androidripper.automation.RobotUtilities.longClick;
import static it.unina.androidripper.automation.RobotUtilities.openMenu;
import static it.unina.androidripper.automation.RobotUtilities.pressKey;
import static it.unina.androidripper.automation.RobotUtilities.scrollDown;
import static it.unina.androidripper.automation.RobotUtilities.searchText;
import static it.unina.androidripper.automation.RobotUtilities.selectListItem;
import static it.unina.androidripper.automation.RobotUtilities.selectRadioItem;
import static it.unina.androidripper.automation.RobotUtilities.selectSpinnerItem;
import static it.unina.androidripper.automation.RobotUtilities.setProgressBar;
import static it.unina.androidripper.automation.RobotUtilities.typeText;
import static it.unina.androidripper.automation.RobotUtilities.writeText;
import static it.unina.androidripper.storage.Resources.*;
import static it.unina.androidripper.strategy.Resources.*;

@SuppressLint("UseSparseArrays")
@SuppressWarnings("rawtypes")
public class AndroidGuiTestHelper extends Engine{

	public static String TAG = "RipperTestCase";

	// Attributes
	private Activity theActivity;
	private SparseArray<View> theViews = new SparseArray<View> ();
	private ArrayList<View> allViews = new ArrayList<View>(); // A list of all widgets
	protected Solo solo;
	private TabHost	tabs;
	private int tabNum;

	List<ActivityState> activities;
	Comparator comparator;
	Automation automation;
	GuiTreeAbstractor guiTreeAbstractor;

	public final static String PACKAGE_NAME ="aarddict.android";
	public final static String CLASS_NAME = "aarddict.android.LookupActivity";
	public final static int SLEEP_AFTER_EVENT = 2000;
	public final static int SLEEP_AFTER_RESTART = 2000;
	public final static int SLEEP_ON_THROBBER = 2000;
	public final static int SLEEP_AFTER_TASK = 5000;
	public final static boolean FORCE_RESTART = false;

	public final static boolean IN_AND_OUT_FOCUS= true;

	public final static String CLICK = "click";
	public final static String BACK = "back";
	public final static String SCROLL_DOWN = "scrollDown";
	public final static String SWAP_TAB = "swapTab";
	public final static String TYPE_TEXT = "editText";
	public final static String LIST_SELECT = "selectListItem";
	public final static String LONG_CLICK = "longClick";
	public final static String LIST_LONG_SELECT = "longClickListItem";
	public final static String OPEN_MENU = "openMenu";
	public final static String SET_BAR = "setBar";
	public final static String SPINNER_SELECT = "selectSpinnerItem";
	public final static String CHANGE_ORIENTATION = "changeOrientation";
	public final static String CLICK_ON_TEXT = "clickText";
	public final static String WRITE_TEXT = "writeText";
	public final static String PRESS_KEY = "pressKey";
	public final static String RADIO_SELECT = "selectRadioItem";
	public final static String ACCELEROMETER_SENSOR_EVENT = "accelerometerSensorEvent";
	public final static String ORIENTATION_SENSOR_EVENT = "orientationSensorEvent";
	public final static String MAGNETIC_FIELD_SENSOR_EVENT = "magneticFieldSensorEvent";
	public final static String TEMPERATURE_SENSOR_EVENT = "temperatureSensorEvent";
	public final static String AMBIENT_TEMPERATURE_SENSOR_EVENT = "ambientTemperatureSensorEvent";
	public final static String GPS_LOCATION_CHANGE_EVENT = "gpsLocationChangeEvent";
	public final static String GPS_PROVIDER_DISABLE_EVENT = "gpsProviderDisableEvent";
	public final static String INCOMING_SMS_EVENT = "incomingSMSEvent";
	public final static String INCOMING_CALL_EVENT = "incomingCallEvent";
	public final static String FOCUS = "focus";
	public final static String BUTTON = "button";
	public final static String EDIT_TEXT = "editText";
	public final static String SEARCH_BAR = "searchBar";
	public final static String RADIO = "radio";
	public final static String RADIO_GROUP = "radioGroup";
	public final static String CHECKBOX = "check";
	public final static String TOGGLE_BUTTON = "toggle";
	public final static String TAB_HOST = "tabHost";
	public final static String NULL = "null";
	public final static String LIST_VIEW = "listView";
	public final static String SPINNER = "spinner";
	public final static String TEXT_VIEW = "text";
	public final static String MENU_VIEW = "menu";
	public final static String IMAGE_VIEW = "image";
	public final static String DIALOG_VIEW = "dialog";
	public final static String SEEK_BAR = "seekBar";
	public final static String RATING_BAR = "ratingBar";
	public final static String LINEAR_LAYOUT = "linearLayout";
	public final static String WEB_VIEW = "webPage";
	public final static String DATE_PICKER = "datePicker";
	public final static String TIME_PICKER = "timePicker";
	public final static String LIST_ITEM = "listItem";
	public final static String SPINNER_INPUT = "spinnerInput";
	public final static String MENU_ITEM = "menuItem";
	public final static String EMPTY_LIST = "emptyList";
	public final static String SINGLE_CHOICE_LIST = "singleChoiceList";
	public final static String MULTI_CHOICE_LIST = "multiChoiceList";
	public final static String PREFERENCE_LIST = "preferenceList";
	public final static String EMPTY_SPINNER = "emptySpinner";
	public final static String RELATIVE_LAYOUT = "relativeLayout";
	public final static String FOCUSABLE_EDIT_TEXT = "focusableEditText";
	public final static String[] PRECRAWLING = {};
	public final static boolean navigation = it.unina.androidripper.Resources.navigation;
	private boolean precrawlNeeded = it.unina.androidripper.strategy.comparator.Resources.precrawl;
	//private Extractor extractor;

	private static Class<?> theClass;
	static {
		try {
			theClass = Class.forName(CLASS_NAME);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	@SuppressWarnings("unchecked")
	public AndroidGuiTestHelper () {

		super();
		
		setScheduler(getNewScheduler());

		this.theAutomation = getNewAutomation();
		this.theRestarter = new BasicRestarter();
		this.theAutomation.setRestarter(theRestarter);
		setRobot (this.theAutomation);
		setExtractor (this.theAutomation);
		setImageCaptor(this.theAutomation);

		try {
			GuiTree.setValidation(false);
			this.guiAbstractor = new GuiTreeAbstractor();
			this.theGuiTree = this.guiAbstractor.getTheSession();
			GregorianCalendar c=new GregorianCalendar();
			theGuiTree.setDateTime(c.getTime().toString());
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setAbstractor(this.guiAbstractor);
		setSession (this.theGuiTree);

		String className = "it.unina.androidripper.planning." + it.unina.androidripper.planning.Resources.PLANNER;
		SimplePlanner p;
		try {
			p = (SimplePlanner)Class.forName(className).newInstance();
		} catch (Exception e) {		
			//e.printStackTrace();
			Log.e("androidripper", "Error during planner instantiation: " + e.toString());
			throw new RuntimeException(e);
		}		


		Filter inputFilter = new FormFilter();
		p.setInputFilter (inputFilter);
		this.guiAbstractor.addFilter (inputFilter);

		Filter eventFilter = new AllPassFilter(); //SimpleEventFilter();
		p.setEventFilter (eventFilter);
		this.guiAbstractor.addFilter (eventFilter);
		this.guiAbstractor.setTypeDetector(new SimpleTypeDetector());

		this.user = UserFactory.getUser(this.guiAbstractor);
		p.setUser(user);
		p.setFormFiller(user);
		p.setAbstractor(this.guiAbstractor);
		setPlanner (p);

		StrategyFactory sf = new StrategyFactory(Resources.COMPARATOR, ADDITIONAL_CRITERIAS);
		sf.setDepth(TRACE_MAX_DEPTH);
		sf.setMaxTraces(MAX_NUM_TRACES);
		sf.setMaxSeconds(MAX_TIME_CRAWLING);
		sf.setPauseSeconds(PAUSE_AFTER_TIME);
		sf.setCheckTransitions(CHECK_FOR_TRANSITION);
		sf.setPauseTraces(PAUSE_AFTER_TRACES);
		sf.setExploreNewOnly(EXPLORE_ONLY_NEW_STATES);
		sf.setMinDepth(TRACE_MIN_DEPTH);
		sf.setStopEvents(AFTER_EVENT_DONT_EXPLORE);
		sf.setStopWidgets(AFTER_WIDGET_DONT_EXPLORE);
		this.theStrategyFactory = sf; // Save in a field so that subclasses can modify the parameters of the strategy

		// Last object to instantiate: the other components register as listeners on the factory class
		this.thePersistenceFactory = new PersistenceFactory (this.theGuiTree, getScheduler());
		if(this.precrawlNeeded)
			addPrecrawling();

	}

	protected void setUp (){		

		solo = new Solo(getInstrumentation(), getActivity());
		Strategy s = this.theStrategyFactory.getStrategy();
		setStrategy (s);
		this.thePersistenceFactory.setStrategy(s);
		setPersistence (this.thePersistenceFactory.getPersistence());
		try {
			super.setUp();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		theRestarter.setRestartPoint(theAutomation.getActivity());
		theGuiTree.setAppName(theAutomation.getAppName());
		theGuiTree.setSleepAfterEvent(SLEEP_AFTER_EVENT);
		theGuiTree.setSleepAfterRestart(SLEEP_AFTER_RESTART);
		theGuiTree.setSleepOnThrobber(SLEEP_ON_THROBBER);
		theGuiTree.setClassName(CLASS_NAME);
		theGuiTree.setPackageName(PACKAGE_NAME);
		theGuiTree.setComparationWidgets(Resources.COMPARATOR.describe());
		theGuiTree.setInAndOutFocus(IN_AND_OUT_FOCUS);
		theGuiTree.setSleepAfterTask(SLEEP_AFTER_TASK);
		theGuiTree.setRandomSeed(RANDOM_SEED);
		theGuiTree.setMaxDepth(TRACE_MAX_DEPTH);
		if (!ACTIVITY_DESCRIPTION_IN_SESSION) {
			theGuiTree.setStateFileName(ACTIVITY_LIST_FILE_NAME);
		}

		if (it.unina.androidripper.planning.Resources.DICTIONARY_FIXED_VALUE){
			Context ctx = this.getActivity().getApplicationContext();

			if (ctx == null)
				ctx = this.getInstrumentation().getTargetContext().getApplicationContext();

			ValuesCache.init(ctx);
		}

		configureSimpleComparator();

		//beforeclass ;-)
		//if (activities == null){
		if(!this.precrawlNeeded){
			try {
				activities = importActivitiyList(getInstrumentation(), "activities.xml");
				for (ActivityState activity : activities){
					s.addState(activity);
				}
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/*
	@Override
	protected void tearDown() throws Exception{
		try {
			solo.finalize();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		getActivity().finish();
		super.tearDown();
	}
	*/
	
	@Override
	public void tearDown() throws Exception {
		//solo.finishOpenedActivities();
		super.tearDown();
	}

	public Session getNewSession() {
		try {
			return new GuiTree();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public TraceDispatcher getNewScheduler() {
		return new TraceDispatcher();
	}

	public Automation getNewAutomation() {
		return new Automation();
	}

	public boolean stepPersistence () {
		return (MAX_TRACES_IN_RAM>0);
	}

	protected static Automation theAutomation;
	private GuiTreeAbstractor guiAbstractor;
	private UserAdapter user;
	private BasicRestarter theRestarter;
	private GuiTree theGuiTree;
	protected StrategyFactory theStrategyFactory;
	protected PersistenceFactory thePersistenceFactory;

	public boolean isAlreadyExploredState(Activity activity, String testname, int transition, int input)
	{
		Log.d("Carmine","isAlreadyExploredState2");

		try {
			this.setUp2();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		boolean isAlreadyExplored = this.testAndCrawl(solo.getCurrentActivity());
		if(!isAlreadyExplored){
			Log.d("NEW_STATE_FOUND", "NEW_STATE_FOUND in #"+testname+", transition n."+transition+", inputs n."+input);
			new_state(testname,transition,input);
			return false;
		}

		Log.d("NO_NEW_STATE_FOUND", "NO_NEW_STATE_FOUND in "+testname+" and transition "+transition);
		//TODO da editare in true
		return false;

	}

	private void new_state(String testname, int transition, int input) {
		ContextWrapper w = new ContextWrapper(this.getActivity());
		FileOutputStream fOut;
		try {
			Log.d("Carmine","The end!!!");
			fOut = w.openFileOutput("new_state.txt", ContextWrapper.MODE_PRIVATE);
			OutputStreamWriter osw = new OutputStreamWriter(fOut); 
			osw.write("NEW_STATE_FOUND in #"+testname+", transition n."+transition+", inputs n."+input);
			osw.flush();
			osw.close();
			fOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		
	}


	public boolean crawler(Activity activity, String testname, int transition)
	{
		/*
		try {
			super.setUp();
		} catch (Exception e) {

			e.printStackTrace();
		}
		*/
		
		Log.d("Carmine","Crawling " + solo.getCurrentActivity().getLocalClassName());
		
		Log.d("Carmine","Crawling " + activity.getLocalClassName());
		
		
		ExtractorUtilities.setActivity(activity);
		ActivityDescription d = getExtractor().describeActivity();
		ActivityState theActivity = getAbstractor().createActivity(d);
		
		Log.d("Carmine","the current activity is "+theActivity.getName());
		

		boolean isAlreadyExplored = this.testAndCrawl();

		if(!isAlreadyExplored){
			Log.e("NEW_STATE_FOUND", "NEW_STATE_FOUND in "+testname+" and transition "+transition);
			return false;
		}

		Log.e("NO_NEW_STATE_FOUND", "NO_NEW_STATE_FOUND in "+testname+" and transition "+transition);
		//TODO da editare in true
		return false;
		
	}


	public List<ActivityState> importActivitiyList(Instrumentation instr, String filename) throws ParserConfigurationException {
		List<String> entries;
		GuiTree sandboxSession = new GuiTree();
		Element e;
		entries = readStateFile(instr, filename);
		List<ActivityState> stateList = new ArrayList<ActivityState>();
		ActivityState s;
		for (String state: entries) {
			sandboxSession.parse(state);
			e = ((XmlGraph)sandboxSession).getDom().getDocumentElement();
			s = sandboxSession.importState (e);
			stateList.add(s);
			Log.d(TAG, "0Imported activity state " + s.getId() + " from disk");
		}

		return stateList;
	}

	public List<String> readStateFile (Instrumentation instr, String filename) {
		FileInputStream theFile;
		BufferedReader theStream = null;
		String line;
		List<String> output = new ArrayList<String>();
		Log.i(TAG, "Reading state file");
		try{
			Context ctx = instr.getContext();
			theFile = ctx.openFileInput (filename);
			theStream = new BufferedReader (new FileReader (theFile.getFD()));

			while ( (line = theStream.readLine()) != null) {
				output.add(line);
			}
			theStream.close();
			theFile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		Log.e("AAA",""+output.size());

		return output;
	}

	public Comparator configureSimpleComparator()
	{
		it.unina.androidripper.strategy.comparator.Resources.COMPARATOR_TYPE = "CustomWidgetsSimpleComparator";

		String[] widgetType = {"editText","button", "menu", "dialog", "listView", "singleChoiceList", "multiChoiceList", "webPage", "tabHost"};
		it.unina.androidripper.strategy.comparator.Resources.WIDGET_TYPES = widgetType;

		it.unina.androidripper.strategy.comparator.Resources.COMPARE_STATE_TITLE = false;//
		it.unina.androidripper.strategy.comparator.Resources.COMPARE_LIST_COUNT = false;//
		it.unina.androidripper.strategy.comparator.Resources.COMPARE_MENU_COUNT = true;

		return new CustomWidgetsSimpleComparator (it.unina.androidripper.strategy.comparator.Resources.WIDGET_TYPES);
	}

	public Comparator configureIntensiveComparator()
	{
		it.unina.androidripper.strategy.comparator.Resources.COMPARATOR_TYPE = "CustomWidgetsIntensiveComparator";

		String[] widgetType = {"editText","button", "menu", "dialog", "listView", "singleChoiceList", "multiChoiceList", "webPage", "tabHost"};
		it.unina.androidripper.strategy.comparator.Resources.WIDGET_TYPES = widgetType;

		it.unina.androidripper.strategy.comparator.Resources.COMPARE_STATE_TITLE = true;
		it.unina.androidripper.strategy.comparator.Resources.COMPARE_LIST_COUNT = true;
		it.unina.androidripper.strategy.comparator.Resources.COMPARE_MENU_COUNT = true;

		return new CustomWidgetsIntensiveComparator (it.unina.androidripper.strategy.comparator.Resources.WIDGET_TYPES);
	}
	//Helper methods for doing the actual work with instrumentation

	public void afterRestart() {
		solo.setActivityOrientation(Solo.PORTRAIT);
		wait(SLEEP_AFTER_RESTART);
		waitOnThrobber();
		if ((PRECRAWLING.length>0) && this.precrawlNeeded) {
			this.precrawlNeeded = false;
			refreshCurrentActivity();
			extractState();
			addPrecrawling();
		}
		Log.d("androidripper", "Ready to operate after restarting...");
	}

	public void wait (int milli) {
		RobotUtilities.wait(milli);
	}

	public void extractState() {

	}


	/*
	public void waitOnThrobber() {
		boolean flag;
		do {
			flag = false;
			ArrayList<ProgressBar> bars = solo.getCurrentProgressBars();
			for (ProgressBar b: bars) {
				if (b.isShown() && b.isIndeterminate()) {
					Log.d("nofatclips", "Waiting on Progress Bar #" + b.getId());
					flag = true;
					solo.sleep(500);
				}
			}
		} while (flag);
	}
	 */
	public void waitOnThrobber() {
		int sleepTime = SLEEP_ON_THROBBER;
		if (sleepTime==0) return;

		boolean flag;
		do {
			flag = false;
			int oldId = 0;
			ArrayList<ProgressBar> bars = solo.getCurrentViews(ProgressBar.class);
			for (ProgressBar b: bars) {
				if (b.isShown() &&  b.isIndeterminate()) {
					int newId = b.getId();
					if (newId != oldId) { // Only log if the throbber changed since the last time
						Log.d("androidripper", "Waiting on Progress Bar #" + newId);
						oldId = newId;
					}
					flag = true;
					RobotUtilities.wait(500);
					sleepTime-=500;
				}
			}
		} while (flag && (sleepTime>0));
		sync();
	}

	public void retrieveWidgets () {
		RobotUtilities.home();;
		clearWidgetList();
		ArrayList<View> viewList = (isInAndOutFocusEnabled())?solo.getViews():solo.getCurrentViews();
		for (View w: viewList) {
			String text = (w instanceof TextView)?": "+((TextView)w).getText().toString():"";
			Log.d("nofatclips", "Found widget: id=" + w.getId() + " ("+ w.toString() + ")" + text); // + " in window at [" + xy[0] + "," + xy[1] + "] on screen at [" + xy2[0] + "," + xy2[1] +"]");

			//
			allViews.add(w);
			//

			if (w.getId()>0) {
				theViews.put(w.getId(), w); // Add only if the widget has a valid ID
			}
			if (w instanceof TabHost) {
				setTabs((TabHost)w);
			}
		}
	}

	public void setTabs (TabHost t) {
		this.tabs = t;
		this.tabNum = t.getTabWidget().getTabCount();
	}

	public SparseArray<View> getWidgets () {
		return this.theViews;
	}

	public View getWidget (int key) {
		return getWidgets().get(key);
	}

	public View getWidget (int theId, String theType, String theName) {
		for (View testee: getWidgetsById(theId)) {
			if (checkWidgetEquivalence(testee, theId, theType, theName)) {
				return testee;
			}
		}
		return null;
	}

	public View getWidget (String theType, String theName) {
		for (View testee: getWidgetsByType(theType)) {
			if (checkWidgetEquivalence(testee, theType, theName)) {
				return testee;
			}
		}
		return null;
	}

	public boolean checkWidgetEquivalence (View testee, int theId, String theType, String theName) {
		return ((theId == testee.getId()) && checkWidgetEquivalence (testee, theType, theName));
	}

	public boolean checkWidgetEquivalence (View testee, String theType, String theName) {
		Log.i("nofatclips", "Retrieved from return list id=" + testee.getId());
		String testeeSimpleType = getSimpleType(testee);
		String testeeType = testee.getClass().getName();
		Log.i("nofatclips", "Testing for type (" + testeeType + ") against the original (" + theType + ")");
		String testeeText = (testee instanceof TextView)?(((TextView)testee).getText().toString()):"";

		String testeeName = testeeText;
		if (testee instanceof EditText) {
			CharSequence hint = ((EditText)testee).getHint();
			testeeName = (hint==null)?"":hint.toString();
		}

		//		String testeeName = (testee instanceof EditText)?(((EditText)testee).getHint().toString()):testeeText;
		Log.i("nofatclips", "Testing for name (" + testeeName + ") against the original (" + theName + ")");
		if ( ((theType.equals(testeeType)) || (theType.equals(testeeSimpleType)) ) && (theName.equals(testeeName)) ) {
			return true;
		}
		return false;
	}


	public ArrayList<View> getWidgetsById (int id) {
		ArrayList<View> theList = new ArrayList<View>();
		for (View theView: getAllWidgets()) {
			if (theView.getId() == id) {
				Log.i("nofatclips", "Added to return list id=" + id);
				theList.add(theView);
			}
		}
		return theList;
	}

	public ArrayList<View> getWidgetsByType (String type) {
		ArrayList<View> theList = new ArrayList<View>();
		for (View theView: getAllWidgets()) {
			if (theView.getClass().getName().equals(type)) {
				Log.i("nofatclips", "Added to return list " + type + " with id=" + theView.getId());
				theList.add(theView);
			}
		}
		return theList;
	}

	public ArrayList<View> getAllWidgets () {
		return this.allViews;
	}

	public void clearWidgetList() {
		theViews.clear();
		allViews.clear();
	}

	public void doTestWidget (int theId, String theType, String theName) {
		if (theId == -1) return;
		assertNotNull("Testing for id #" + theId + " (" + theType + "): " + theName, getWidget(theId, theType, theName));
	}

	public void doTestWidget (String theType, String theName) {
		assertNotNull("Testing for type " + theType + "): " + theName, getWidget(theType, theName));
	}

	public void fireEvent (int widgetId, int widgetIndex, String widgetType, String eventType) {
		//fireEvent(widgetId, widgetIndex, widgetType, eventType, null);
		fireEvent(widgetId, widgetIndex, "", widgetType, eventType);
	}

	public void fireEvent (int widgetId, int widgetIndex, String widgetName, String widgetType, String eventType) {
		fireEvent(widgetId, widgetIndex, widgetName, widgetType, eventType, null);
	}

	public void fireEvent (int widgetIndex, String widgetName, String widgetType, String eventType) {
		fireEvent(widgetIndex, widgetName, widgetType, eventType, null);
	}

	public void fireEvent (int widgetId, int widgetIndex, String widgetName, String widgetType, String eventType, String value) {

		View v = null;
		if (widgetIndex<getAllWidgets().size()) {
			v = getAllWidgets().get(widgetIndex); // Search widget by index
		}
		if ((v!=null) && !checkWidgetEquivalence(v, widgetId, widgetType, widgetName)) {
			v = getWidget(widgetId, widgetType, widgetName);
		}
		if (v == null) {
			v = getWidget(widgetId);
		}
		if (v == null) {
			v = theActivity.findViewById(widgetId);
		}
		fireEventOnView (v, eventType, value);
	}

	public void fireEvent (int widgetIndex, String widgetName, String widgetType, String eventType, String value) {
		View v = null;
		if (eventType.equals(BACK) || eventType.equals(SCROLL_DOWN)) {
			fireEventOnView(null, eventType, null);
			return;
		} else if (eventType.equals(CLICK_ON_TEXT)) {
			Log.d("nofatclips", "Firing event: type= " + eventType + " value= " + value);
			fireEventOnView(null, eventType, value);
		}
		if (widgetType.equals(BUTTON)) {
			v = solo.getButton(widgetName);
		} else if (widgetType.equals(MENU_ITEM)) {
			v = solo.getText(widgetName);
		} else if (widgetType.equals(LIST_VIEW)) {
			v = solo.getCurrentViews(ListView.class).get(0);
		}
		if (v == null) {
			for (View w: getAllWidgets()) {
				if (w instanceof Button) {
					Button candidate = (Button) w;
					if (candidate.getText().equals(widgetName)) {
						v = candidate;
					}
				}
				if (v!=null) break;
			}
		}
		fireEventOnView (v, eventType, value);
	}

	private void fireEventOnView (View v, String eventType, String value) {
		injectInteraction(v, eventType, value);
		solo.sleep(SLEEP_AFTER_EVENT);
		waitOnThrobber();
		refreshCurrentActivity();
	}

	public void setInput (int widgetId, String inputType, String value) {
		View v = getWidget(widgetId);
		if (v == null) {
			v = theActivity.findViewById(widgetId);
		}
		injectInteraction(v, inputType, value);
	}

	private void injectInteraction (View v, String interactionType, String value) {

		Log.d("Carmine","InjectInteraction0");
		if (v!=null) {
			Log.d("Carmine","InjectInteraction1");
			requestView(v);
		}

		if (interactionType.equals(CLICK)) {
			Log.d("Carmine","InjectInteraction2");
			click (v);
		} else if (interactionType.equals(LONG_CLICK)) {
			Log.d("Carmine","InjectInteraction3");
			longClick(v);

		} else if (interactionType.equals(BACK)) {
			Log.d("Carmine","InjectInteraction4");
			goBack();
		} else if (interactionType.equals(OPEN_MENU)) {
			Log.d("Carmine","InjectInteraction5");
			openMenu();
		} else if (interactionType.equals(HOME_ACTION)) {
			Log.d("Carmine","InjectInteraction6");
			ActionBarHome();
		} else if (interactionType.equals(SCROLL_DOWN)) {
			scrollDown();
		} else if (interactionType.equals(CHANGE_ORIENTATION)) {
			changeOrientation();

		} else if (interactionType.equals(CLICK_ON_TEXT)) {
			clickOnText(value);
		} else if (interactionType.equals(PRESS_KEY)) {
			pressKey(value);

		} else if (interactionType.equals(SWAP_TAB) && (value!=null)) {
			if (v instanceof TabHost) {
				RobotUtilities.swapTab (v, value);
			} else {
				swapTab (value);
			}
		} else if (interactionType.equals(LIST_SELECT)) {
			selectListItem((ListView)v, value);
		} else if (interactionType.equals(LIST_LONG_SELECT)) {
			selectListItem((ListView)v, value, true);

		} else if (interactionType.equals(SPINNER_SELECT)) {
			selectSpinnerItem((Spinner)v, value);
		} else if (interactionType.equals(RADIO_SELECT)) {
			selectRadioItem((RadioGroup)v, value);

		} else if (interactionType.equals(TYPE_TEXT)) {
			typeText((EditText)v, value);
		} else if (interactionType.equals(WRITE_TEXT)) {
			writeText((EditText)v, value);
		} else if (interactionType.equals(SEARCH_TEXT)) {
			searchText((EditText)v, value);	
		} else if (interactionType.equals(AUTO_TEXT)) {
			writeText((EditText)v, value);	
		} else if (interactionType.equals(FOCUS)) {
			focus (v, value);

		} else if (interactionType.equals(DRAG)) {
			drag(v);

		} else if (interactionType.equals(SET_BAR)) {
			setProgressBar(v, value);

		} else {
			return;
		}
	}

	public void swapTab (String tab) {
		RobotUtilities.swapTab (this.tabs, tab);
	}


	protected void typeText (EditText v, String value) {
		solo.enterText(v, value);
	}

	protected void writeText (EditText v, String value) {
		typeText (v, "");
		typeText (v, value);
	}

	public void changeOrientation() {
		Display display = ((WindowManager) getInstrumentation().getContext().getSystemService(WINDOW_SERVICE)).getDefaultDisplay();
		int angle = display.getRotation();
		int newAngle = ((angle==ROTATION_0)||(angle==ROTATION_180))?Solo.LANDSCAPE:Solo.PORTRAIT;
		solo.setActivityOrientation(newAngle);
	}

	private void swapTab (TabHost t, String tab) {
		swapTab (t, Integer.valueOf(tab));
	}

	private void swapTab (final TabHost t, int num) {
		final int n = Math.min(this.tabNum, Math.max(1,num))-1;
		Log.i("nofatclips", "Swapping to tab " + num);
		getActivity().runOnUiThread(new Runnable() {
			public void run() {
				t.setCurrentTab(n);
			}
		});
		sync();
	}

	private void clickOnText (String text) {
		solo.clickOnText (text);
	}

	private void selectListItem (ListView l, String item) {
		selectListItem (l, Integer.valueOf(item), false);
	}

	private void selectListItem (ListView l, String item, boolean longClick) {
		selectListItem (l, Integer.valueOf(item), longClick);
	}

	private void selectListItem (final ListView l, int num, boolean longClick) {
		final int n = Math.min(l.getCount(), Math.max(1,num))-1;
		requestFocus(l);
		Log.i("nofatclips", "Swapping to listview item " + num);
		solo.sendKey(Solo.DOWN);
		getActivity().runOnUiThread(new Runnable() {
			public void run() {
				l.setSelection(n);
			}
		});
		sync();
		if (n<l.getCount()/2) {
			solo.sendKey(Solo.DOWN);
			solo.sendKey(Solo.UP);
		} else {
			solo.sendKey(Solo.UP);
			solo.sendKey(Solo.DOWN);
		}
		sync();
		if (longClick) {
			longClick (l.getSelectedView());
		} else {
			click (l.getSelectedView());
		}
	}

	public static boolean isInAndOutFocusEnabled () {
		return IN_AND_OUT_FOCUS;
	}

	protected void requestFocus (final View v) {
		getActivity().runOnUiThread(new Runnable() {
			public void run() {
				v.requestFocus();
			}
		});
		sync();
	}

	public void pressKey (String keyCode) {
		pressKey (Integer.parseInt(keyCode));
	}

	public void pressKey (int keyCode) {
		solo.sendKey(keyCode);
	}

	// Scroll until the view is on the screen if IN_AND_OUT_OF_FOCUS is enabled or if the force parameter is true
	protected void requestView (final View v, boolean force) {
		if (force || isInAndOutFocusEnabled()) {
			home();
			solo.sendKey(Solo.UP); // Solo.waitForView() requires a widget to be focused
			solo.waitForView(v, 1000, true);
		}
		requestFocus(v);
	}

	protected void requestView (final View v) {
		requestView(v, false);
	}


	private void selectSpinnerItem (Spinner l, String item) {
		selectSpinnerItem (l, Integer.valueOf(item));
	}

	private void selectSpinnerItem (final Spinner s, int num) {
		assertNotNull(s, "Cannon press spinner item: the spinner does not exist");
		Log.i("nofatclips", "Clicking the spinner view");
		click(s);
		sync();
		selectListItem(solo.getCurrentViews(ListView.class).get(0), num, false);
	}

	protected void click (View v) {
		// TouchUtils.clickView(this, v);
		solo.clickOnView(v);
	}

	protected void longClick (View v) {
		solo.clickLongOnView(v);
	}

	public void home () {

		// Scroll listviews up
		final ArrayList<ListView> viewList = solo.getCurrentViews(ListView.class);
		if (viewList.size() > 0) {
			getActivity().runOnUiThread(new Runnable() {
				public void run() {
					viewList.get(0).setSelection(0);
				}
			});
		}

		// Scroll scrollviews up
		final ArrayList<ScrollView> viewScroll = solo.getCurrentViews(ScrollView.class);
		if (viewScroll.size() > 0) {
			getActivity().runOnUiThread(new Runnable() {
				public void run() {
					viewScroll.get(0).fullScroll(ScrollView.FOCUS_UP);
				}
			});
		}
		sync();
	}


	public void restart() {
		if (FORCE_RESTART) {
			ContextWrapper main = new ContextWrapper(solo.getCurrentActivity());
			Intent i = main.getBaseContext().getPackageManager().getLaunchIntentForPackage(main.getBaseContext().getPackageName() );
			i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK );
			main.startActivity(i);
		}
	}

	private void refreshCurrentActivity() {
		ExtractorUtilities.setActivity(solo.getCurrentActivity());
		//Log.i("nofatclips", "Current activity is " + getActivity().getLocalClassName());
		Log.i("androidripper", "2Current activity is " + solo.getCurrentActivity().getLocalClassName());
	}

	public String getSimpleType(View v) {
		String type = v.getClass().getName();
		if (type.endsWith("null"))
			return NULL;
		if (type.endsWith("RadioButton"))
			return RADIO;
		if (type.endsWith("CheckBox") || type.endsWith("CheckedTextView"))
			return CHECKBOX;
		if (type.endsWith("ToggleButton"))
			return TOGGLE_BUTTON;
		if (type.endsWith("IconMenuView"))
			return MENU_VIEW;
		if (type.endsWith("DatePicker"))
			return DATE_PICKER;
		if (type.endsWith("TimePicker"))
			return TIME_PICKER;
		if (type.endsWith("IconMenuItemView"))
			return MENU_ITEM;
		if (type.endsWith("DialogTitle"))
			return DIALOG_VIEW;
		if (type.endsWith("Button"))
			return BUTTON;
		if (type.endsWith("EditText"))
			return EDIT_TEXT;
		if (type.endsWith("Spinner")) {
			Spinner s = (Spinner)v;
			if (s.getCount() == 0) return EMPTY_SPINNER;
			return SPINNER;
		}
		if (type.endsWith("SeekBar"))
			return SEEK_BAR;
		if (v instanceof RatingBar && (!((RatingBar)v).isIndicator()))
			return RATING_BAR;
		if (type.endsWith("TabHost"))
			return TAB_HOST;
		if (type.endsWith("ListView") || type.endsWith("ExpandedMenuView")) {
			ListView l = (ListView)v;
			if (l.getCount() == 0) return EMPTY_LIST;

			if (l.getAdapter().getClass().getName().endsWith("PreferenceGroupAdapter")) {
				return PREFERENCE_LIST;
			}

			switch (l.getChoiceMode()) {
			case ListView.CHOICE_MODE_NONE: return LIST_VIEW;
			case ListView.CHOICE_MODE_SINGLE: return SINGLE_CHOICE_LIST;
			case ListView.CHOICE_MODE_MULTIPLE: return MULTI_CHOICE_LIST;
			}
		}
		if (type.endsWith("TextView"))
			return TEXT_VIEW;
		if (type.endsWith("ImageView"))
			return IMAGE_VIEW;
		if (type.endsWith("LinearLayout"))
			return LINEAR_LAYOUT;
		if ((v instanceof WebView) || type.endsWith("WebView"))
			return WEB_VIEW;
		if (type.endsWith("TwoLineListItem"))
			return LIST_ITEM;
		return "";
	}

	protected void assertNotNull (final View v) {
		ActivityInstrumentationTestCase2.assertNotNull(v);
	}

	protected void assertNotNull (final View v, String errorMessage) {
		ActivityInstrumentationTestCase2.assertNotNull(errorMessage, v);
	}

	public void sync() {
		getInstrumentation().waitForIdleSync();
	}
	
	
	public void addPrecrawling(){
		
		theAutomation.precrawlNeeded = true;

		this.guiAbstractor.activityId = 0;
		
	}

	private void addNewEvent(String s1, String s2, String s3, String s4) {
		
		String[] params = {s1,s2,s3,s4};
		theAutomation.PRECRAWLING.add(params);
		
	}

	/*
	public void debug (String msg) {
		Log.d("nofatclips",msg);
		for (View x: getWidgets().values()) {
			if (x instanceof TextView) {
				Log.i("nofatclips", ((TextView)x).getText().toString() + "[" + x.toString() + "]: " + x.getId());
			} else {
				Log.i("nofatclips", "[" + x.toString() + "]: " + x.getId());
			}
		}
	}
	 */

}
